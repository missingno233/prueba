using System.Net;
using System.Net.Sockets;

namespace TestinShiiiiiitttt
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            markdownViewer.LoadMarkdownAsync("C:\\Users\\Elias\\source\\repos\\Desarrollo de Sistemas 3\\TestinShiiiiiitttt\\Properties\\md\\DeepSeek\\Apache POI.md");
        }
    }
}
