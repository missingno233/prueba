# Customer Support Chat Transcript
**Session ID:** CS-2023-10-27-0421  
**Timestamp:** 2023-10-27 14:21:05 UTC  
**Agent:** Nova (AI Assistant)  
**Client:** Alex Chen  

---

**👤 Alex Chen** (14:21:09):  
Hi, I’m having trouble logging into my account—it says my password is incorrect, but I’m sure I’m typing it right.

**🤖 Nova** (14:21:16):  
Hello Alex! I’m sorry you’re having login issues. Let’s troubleshoot this step by step. First, have you tried the “Forgot Password” option to reset it?

**👤 Alex Chen** (14:21:45):  
Yes, I tried that, but I never received the reset email. I checked my spam folder too.

**🤖 Nova** (14:21:52):  
Thanks for checking. Let’s verify the email on file. Can you confirm the email address you’re using? Please share only the first three characters and the domain for security.

**👤 Alex Chen** (14:22:10):  
It should be ale***@gmail.com.

**🤖 Nova** (14:22:20):  
That matches our records. The issue might be a server-side delay. I’ve just re-sent the reset link. Could you wait 2–3 minutes and check again?  

In the meantime, ensure your browser cache is cleared—sometimes that helps with login pages freezing.

**👤 Alex Chen** (14:23:02):  
Okay, I’ll wait. If I don’t get it, what’s the next step?

**🤖 Nova** (14:23:10):  
If the email doesn’t arrive, I can initiate a manual reset from my end, which may take up to 15 minutes to process. Alternatively, we can set up two-factor authentication for you once we restore access, to improve account security.

**👤 Alex Chen** (14:24:30):  
Got the email now! Reset done—I’m logged in. Thanks for the help.

**🤖 Nova** (14:24:38):  
Excellent! Happy to hear it. For future reference, I recommend updating your password every few months and enabling 2FA. Is there anything else I can assist you with today?

**👤 Alex Chen** (14:25:00):  
No, that’s all. Have a good day.

**🤖 Nova** (14:25:05):  
You too, Alex. Feel free to reach out again if you need assistance.  

**👤 Alex Chen** (14:25:00):  
Ayudame con la librería Apache POI.

**🤖 Nova** (14:25:05):  
Te proporciono las clases y métodos más importantes de Apache POI para trabajar con documentos Word (.docx):

## Clases principales

### 1. **XWPFDocument** - Documento principal
```java
import org.apache.poi.xwpf.usermodel.*;

// Crear un nuevo documento
XWPFDocument document = new XWPFDocument();

// Abrir documento existente
XWPFDocument document = new XWPFDocument(new FileInputStream("documento.docx"));
```

### 2. **XWPFParagraph** - Párrafos
```java
// Crear un párrafo
XWPFParagraph paragraph = document.createParagraph();

// Configurar alineación
paragraph.setAlignment(ParagraphAlignment.CENTER); // LEFT, RIGHT, CENTER, JUSTIFY
```

### 3. **XWPFRun** - Fragmentos de texto con estilo
```java
// Crear un run (fragmento de texto)
XWPFRun run = paragraph.createRun();
```

## Métodos para control de estilo

### Texto básico
```java
XWPFRun run = paragraph.createRun();

// Texto simple
run.setText("Texto normal");

// Negritas
run.setBold(true);
run.setText("Texto en negrita");

// Cursivas
run.setItalic(true);
run.setText("Texto en cursiva");

// Subrayado
run.setUnderline(UnderlinePatterns.SINGLE);

// Tachado
run.setStrikeThrough(true);

// Color del texto
run.setColor("FF0000"); // Rojo en hexadecimal

// Tamaño de fuente
run.setFontSize(14);

// Tipo de fuente
run.setFontFamily("Arial");
```

### Saltos de línea y espacios
```java
// Salto de línea
run.addBreak(); // Salto de línea simple
run.addBreak(BreakType.PAGE); // Salto de página

// Tabulación
run.addTab();

// Múltiples saltos de línea
for(int i = 0; i < 3; i++) {
    run.addBreak();
}
```

### Ejemplo completo
```java
import org.apache.poi.xwpf.usermodel.*;
import java.io.FileOutputStream;

public class EjemploWord {
    public static void main(String[] args) throws Exception {
        XWPFDocument document = new XWPFDocument();
        
        // Título
        XWPFParagraph titulo = document.createParagraph();
        titulo.setAlignment(ParagraphAlignment.CENTER);
        XWPFRun runTitulo = titulo.createRun();
        runTitulo.setBold(true);
        runTitulo.setFontSize(18);
        runTitulo.setText("Mi Documento");
        runTitulo.addBreak();
        
        // Párrafo normal
        XWPFParagraph parrafo1 = document.createParagraph();
        parrafo1.setAlignment(ParagraphAlignment.LEFT);
        XWPFRun run1 = parrafo1.createRun();
        run1.setText("Este es un párrafo normal. ");
        
        // Texto en negrita
        XWPFRun run2 = parrafo1.createRun();
        run2.setBold(true);
        run2.setText("Este texto está en negrita. ");
        
        // Texto en cursiva
        XWPFRun run3 = parrafo1.createRun();
        run3.setItalic(true);
        run3.setText("Este texto está en cursiva.");
        run3.addBreak();
        run3.addBreak();
        
        // Lista con viñetas
        XWPFParagraph lista = document.createParagraph();
        lista.setAlignment(ParagraphAlignment.LEFT);
        lista.setBullet(true); // Activar viñetas
        
        XWPFRun item1 = lista.createRun();
        item1.setText("Primer elemento de la lista");
        item1.addBreak();
        
        XWPFRun item2 = lista.createRun();
        item2.setText("Segundo elemento de la lista");
        item2.setColor("0000FF"); // Azul
        
        // Guardar documento
        FileOutputStream out = new FileOutputStream("mi_documento.docx");
        document.write(out);
        out.close();
        document.close();
        
        System.out.println("Documento creado exitosamente!");
    }
}
```

## Métodos adicionales útiles

### Configuración de párrafo
```java
XWPFParagraph paragraph = document.createParagraph();

// Espaciado
paragraph.setSpacingBetween(1.5); // Interlineado
paragraph.setSpacingBefore(200); // Espacio antes
paragraph.setSpacingAfter(200); // Espacio después

// Sangría
paragraph.setIndentationLeft(400); // Sangría izquierda
paragraph.setIndentationRight(200); // Sangría derecha
paragraph.setIndentationHanging(200); // Sangría francesa
```

### Hipervínculos
```java
// Crear hipervínculo
String url = "https://www.ejemplo.com";
String texto = "Visitar sitio web";
paragraph.createRun().setText(texto);
// Nota: Para hipervínculos necesitas configurar relaciones (más complejo)
```

### Imágenes
```java
// Agregar imagen (requiere FileInputStream)
String imgPath = "imagen.jpg";
FileInputStream imageStream = new FileInputStream(imgPath);
paragraph.createRun().addPicture(
    imageStream, 
    XWPFDocument.PICTURE_TYPE_JPEG, 
    "imagen.jpg", 
    Units.toEMU(200), // Ancho
    Units.toEMU(150)  // Alto
);
imageStream.close();
```

## Dependencia Maven
```xml
<dependency>
    <groupId>org.apache.poi</groupId>
    <artifactId>poi-ooxml</artifactId>
    <version>5.2.3</version>
</dependency>
```

Estas clases y métodos te permitirán crear documentos Word profesionales con control completo sobre el formato y estilo del texto.

**👤 Alex Chen** (14:25:00):  
Gracias!.

*Session ended by client.*